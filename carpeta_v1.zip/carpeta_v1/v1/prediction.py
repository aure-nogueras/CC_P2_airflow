from statsmodels.tsa.arima_model import ARIMA
import pandas as pd
import pmdarima as pm
import matplotlib.pyplot as plt
import numpy as np
from io import StringIO
from dotenv import load_dotenv
import os

import requests

load_dotenv()

""" Clase que contendrá los métodos para realizar las predicciones """
class Prediction:

    def __init__(self):
      """ Inicializador de la clase """
      self.horas = 0
      
    def set_horas(self, horas):
      """ Setter de las horas """
      if not type(horas) is int:
        raise TypeError("Las horas deben ser un número entero")
      self.horas = horas
      
    def get_horas(self):
      """ Getter de las horas """
      return self.horas

    def generate_plot(self, title, data, tipo):
      """ Genera un gráfico para los datos sobre la humedad o la temperatura """
      if not type(title) is str:
        raise TypeError("El título debe ser un string")
      if tipo != "HUM" and tipo != "TEMP":
        raise ValueError("El valor de la variable tipo debe ser HUM o TEMP")
	    
      fig, ax = plt.subplots(figsize=(12, 4))
      data[tipo].plot(ax=ax, label=title, linewidth=0.5)
      ax.legend()
      fig.savefig("static/"+title)
			

    def prediction_arima(self, dataset, horas):
      """ Predicción usando ARIMA """
      self.set_horas(horas)
      col_list = ["DATE", "TEMP", "HUM"]
      df = pd.read_csv(dataset, usecols=col_list)
	  
      df['DATE'] = pd.to_datetime(df['DATE'].str.strip(), format='%Y-%m-%d %H:%M:%S')
      data = df.set_index('DATE')
      data = pd.date_range(data.index[-1], periods=horas+1, freq="1h", closed='right')
	  
      model = pm.auto_arima(df.TEMP, start_p=1, start_q=1,
						  test='adf',       # use adftest to find optimal 'd'
						  max_p=3, max_q=3, # maximum p and q
						  m=1,              # frequency of series
						  d=None,           # let model determine 'd'
						  seasonal=False,   # No Seasonality
						  start_P=0, 
						  D=0, 
						  trace=True,
						  error_action='ignore',  
						  suppress_warnings=True, 
						  stepwise=True)
					  
      model2 = pm.auto_arima(df.HUM, start_p=1, start_q=1,
						  test='adf',       # use adftest to find optimal 'd'
						  max_p=3, max_q=3, # maximum p and q
						  m=1,              # frequency of series
						  d=None,           # let model determine 'd'
						  seasonal=False,   # No Seasonality
						  start_P=0, 
						  D=0, 
						  trace=True,
						  error_action='ignore',  
						  suppress_warnings=True, 
						  stepwise=True)
	
      # Forecast
      n_periods = self.horas 
      fc, confint = model.predict(n_periods=n_periods, return_conf_int=True)
      fc2, confint2 = model2.predict(n_periods=n_periods, return_conf_int=True)

      d = {'DATE':data, 'TEMP':fc, 'HUM':fc2}
      d = pd.DataFrame(data=d)
      d = d.set_index('DATE')
		
      title1 = 'v1_' + str(horas) + 'h_temp.png'
      title2 = 'v1_' + str(horas) + 'h_hum.png'
  
      self.generate_plot(title1, d, 'TEMP')
      self.generate_plot(title2, d, 'HUM')
		
      return d
        
