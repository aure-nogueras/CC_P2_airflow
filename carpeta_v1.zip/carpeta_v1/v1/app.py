# save this as app.py
from flask import Flask, escape, request, render_template
from prediction import Prediction as pr

app = Flask(__name__)


@app.route('/servicio/v1/prediccion/24horas/')
def pred_arima_24h():
    p = pr()
    value = p.prediction_arima('data.csv', 24)
    return render_template('v1_24h.html', val=value)
    
@app.route('/servicio/v1/prediccion/48horas/')
def pred_arima_48h():
    p = pr()
    value = p.prediction_arima('data.csv', 48)
    return render_template('v1_48h.html', val=value)
    
@app.route('/servicio/v1/prediccion/72horas/')
def pred_arima_72h():
    p = pr()
    value = p.prediction_arima('data.csv', 72)
    return render_template('v1_72h.html', val=value)
    
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8082)
