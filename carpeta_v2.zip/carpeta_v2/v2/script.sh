#!/bin/bash
source $HOME/.poetry/env
poetry install
poetry run task web
