# save this as app.py
from flask import Flask, escape, request, render_template
from prediction import Prediction as pr

app = Flask(__name__)


@app.route('/servicio/v2/prediccion/24horas/')
def pred_api_24h():
    p = pr()
    value = p.prediction_api_weather(24)
    return render_template('v2_24h.html', val=value)
    
@app.route('/servicio/v2/prediccion/48horas/')
def pred_api_48h():
    p = pr()
    value = p.prediction_api_weather(48)
    return render_template('v2_48h.html', val=value)
    
@app.route('/servicio/v2/prediccion/72horas/')
def pred_api_72h():
    p = pr()
    value = p.prediction_api_weather(72)
    return render_template('v2_72h.html', val=value)
    
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8083)
