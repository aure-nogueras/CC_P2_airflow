import unittest
from prediction import Prediction as pr

class Test(unittest.TestCase):
  def test_horas(self):
    """ Test de la variable horas """
    p = pr()
    p.set_horas(24)
    self.assertEqual(p.get_horas(), 24)
    with self.assertRaises(TypeError):
      p.set_horas("abc")
      
  def test_plot(self):
    """ Test para comprobar los argumentos de la función que dibuja gráficas """
    p = pr()
    with self.assertRaises(TypeError):
      p.generate_plot(12, "", "TEMP")
    with self.assertRaises(ValueError):
      p.generate_plot("titulo", "", "abc")
      
if __name__ == '__main__':
  unittest.main()
    

