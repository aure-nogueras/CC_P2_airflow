from statsmodels.tsa.arima_model import ARIMA
import pandas as pd
import pmdarima as pm
import matplotlib.pyplot as plt
import numpy as np
from io import StringIO
from dotenv import load_dotenv
import os

import requests

load_dotenv()

""" Clase que contendrá los métodos para realizar las predicciones """
class Prediction:

    def __init__(self):
      """ Inicializador de la clase """
      self.horas = 0
      
    def set_horas(self, horas):
      """ Setter de las horas """
      if not type(horas) is int:
        raise TypeError("Las horas deben ser un número entero")
      self.horas = horas
      
    def get_horas(self):
      """ Getter de las horas """
      return self.horas

    def generate_plot(self, title, data, tipo):
      """ Genera un gráfico para los datos sobre la humedad o la temperatura """
      if not type(title) is str:
        raise TypeError("El título debe ser un string")
      if tipo != "HUM" and tipo != "TEMP":
        raise ValueError("El valor de la variable tipo debe ser HUM o TEMP")
	    
      fig, ax = plt.subplots(figsize=(12, 4))
      data[tipo].plot(ax=ax, label=title, linewidth=0.5)
      ax.legend()
      fig.savefig("static/"+title)
			
    def prediction_api_weather(self, horas):
      """ Predicción usando una API """
      self.set_horas(horas)
      url = "https://visual-crossing-weather.p.rapidapi.com/forecast"
      querystring = {"location":"San Francisco","aggregateHours":"1","shortColumnNames":"0","unitGroup":"us","contentType":"csv"}
      headers = {
        'x-rapidapi-key': os.getenv('KEY'),
        'x-rapidapi-host': "visual-crossing-weather.p.rapidapi.com"
      }
      response = requests.request("GET", url, headers=headers, params=querystring)
      df = StringIO(response.text)
      col_list = ["Date time", "Temperature", "Relative Humidity"]
      df = pd.read_csv(df, usecols=col_list)
      df = df.rename(columns = {'Date time':'DATE', 'Temperature':'TEMP', 'Relative Humidity':'HUM'})
      df = df.iloc[0:horas]
      
      title1 = 'v2_' + str(horas) + 'h_temp.png'
      title2 = 'v2_' + str(horas) + 'h_hum.png'
  
      self.generate_plot(title1, df, 'TEMP')
      self.generate_plot(title2, df, 'HUM')
      
      return df

        
